CREATE VIEW v_a_pipelinesections AS SELECT g.id,
    sp.mapdot AS startpoint,
    ep.mapdot AS endpoint,
    mc.codename AS material,
    g.remarks,
    g.geom,
    sp.x AS startpointx,
    sp.y AS startpointy,
    ep.x AS endpointx,
    ep.y AS endpointy,
    g.pipelineseclength,
    g.status,
    g.pipediameter,
    gc.codename AS piplelinetype,
    g.startburydepth,
    g.endburydepth,
    g.addr
   FROM ((((t_zl_pipelinesections g
     LEFT JOIN t_zl_pipelinepoints sp ON (((g.startpoint)::text = (sp.id)::text)))
     LEFT JOIN t_zl_pipelinepoints ep ON (((g.endpoint)::text = (ep.id)::text)))
     LEFT JOIN t_zl_code mc ON ((((g.material)::text = (mc.codecode)::text) AND ((mc.codetype)::text = '管段材质'::text))))
     LEFT JOIN t_zl_code gc ON ((((g.type)::text = (gc.codecode)::text) AND ((gc.codetype)::text = '管段类型'::text))));
