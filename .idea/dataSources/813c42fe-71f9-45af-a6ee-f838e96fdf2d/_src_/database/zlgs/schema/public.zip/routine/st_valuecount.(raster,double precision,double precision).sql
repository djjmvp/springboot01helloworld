create function st_valuecount(rast raster, searchvalue double precision, roundto double precision DEFAULT 0) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ( public._ST_valuecount($1, 1, TRUE, ARRAY[$2]::double precision[], $3)).count
$$;
