create function st_forcepolygonccw(geometry) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Reverse(public.ST_ForcePolygonCW($1))
$$;
