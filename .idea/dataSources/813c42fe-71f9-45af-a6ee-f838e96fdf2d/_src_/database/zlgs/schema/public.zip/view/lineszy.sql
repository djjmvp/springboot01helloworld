CREATE VIEW lineszy AS SELECT ( SELECT t2.gid
           FROM t_zl_pipelinepoints t2
          WHERE ((t2.id)::text = (t1.startpoint)::text)) AS source,
    ( SELECT t2.gid
           FROM t_zl_pipelinepoints t2
          WHERE ((t2.id)::text = (t1.endpoint)::text)) AS target,
    t1.length,
    t1.pipelineseclength,
    0 AS id
   FROM t_zl_pipelinesections t1;
