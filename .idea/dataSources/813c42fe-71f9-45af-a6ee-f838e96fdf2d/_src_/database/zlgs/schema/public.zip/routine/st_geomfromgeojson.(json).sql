create function st_geomfromgeojson(json) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_GeomFromGeoJson($1::text)
$$;
