create function st_quantile(rast raster, nband integer, quantiles double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_quantile($1, $2, TRUE, 1, $3)
$$;
