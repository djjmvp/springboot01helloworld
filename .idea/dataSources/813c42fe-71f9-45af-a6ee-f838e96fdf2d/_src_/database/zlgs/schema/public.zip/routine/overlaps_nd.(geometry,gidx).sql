create function overlaps_nd(geometry, gidx) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.&&&) $1;
$$;
