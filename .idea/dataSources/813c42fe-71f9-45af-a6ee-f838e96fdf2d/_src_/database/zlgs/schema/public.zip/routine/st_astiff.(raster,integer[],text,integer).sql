create function st_astiff(rast raster, nbands integer[], compression text, srid integer DEFAULT NULL::integer) returns bytea
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT st_astiff(st_band($1, $2), $3, $4)
$$;
