CREATE VIEW pipeline2 AS SELECT ( SELECT t_zl_pipelinepoints.mapdot
           FROM t_zl_pipelinepoints
          WHERE ((t_zl_pipelinepoints.id)::text = (t.startpoint)::text)) AS startpoint,
    ( SELECT t_zl_pipelinepoints.mapdot
           FROM t_zl_pipelinepoints
          WHERE ((t_zl_pipelinepoints.id)::text = (t.endpoint)::text)) AS endpoint,
    t.id,
    t.geom,
    t.mainorbranch,
    (((( SELECT t_zl_pipelinepoints.mapdot
           FROM t_zl_pipelinepoints
          WHERE ((t_zl_pipelinepoints.id)::text = (t.startpoint)::text)))::text || '~'::text) || (( SELECT t_zl_pipelinepoints.mapdot
           FROM t_zl_pipelinepoints
          WHERE ((t_zl_pipelinepoints.id)::text = (t.endpoint)::text)))::text) AS name,
    t.startpoint AS startpointid,
    t.endpoint AS endpointid,
    t.completiondate,
    t1.codename AS type,
    t2.codename AS material,
    t3.codename AS pipediameter
   FROM (((t_zl_pipelinesections t
     LEFT JOIN t_zl_code t1 ON ((((t1.codecode)::text = (t.type)::text) AND ((t1.codetype)::text = '管段类型'::text))))
     LEFT JOIN t_zl_code t2 ON ((((t2.codecode)::text = (t.material)::text) AND ((t2.codetype)::text = '管段材质'::text))))
     LEFT JOIN t_zl_code t3 ON ((((t3.codecode)::text = (t.pipediameter)::text) AND ((t3.codetype)::text = '管径'::text))));
