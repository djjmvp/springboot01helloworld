create function st_geomfromgeojson(jsonb) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_GeomFromGeoJson($1::text)
$$;
