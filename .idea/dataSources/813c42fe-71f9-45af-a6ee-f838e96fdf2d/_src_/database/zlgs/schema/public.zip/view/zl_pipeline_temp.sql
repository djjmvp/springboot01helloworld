CREATE VIEW zl_pipeline_temp AS SELECT ( SELECT t_zl_pipelinepoints_temp.mapdot
           FROM t_zl_pipelinepoints_temp
          WHERE ((t_zl_pipelinepoints_temp.id)::text = (t.startpoint)::text)) AS startpoint,
    ( SELECT t_zl_pipelinepoints_temp.mapdot
           FROM t_zl_pipelinepoints_temp
          WHERE ((t_zl_pipelinepoints_temp.id)::text = (t.endpoint)::text)) AS endpoint,
    t.id,
    t.geom,
    t.mainorbranch,
    (((( SELECT t_zl_pipelinepoints_temp.mapdot
           FROM t_zl_pipelinepoints_temp
          WHERE ((t_zl_pipelinepoints_temp.id)::text = (t.startpoint)::text)))::text || '~'::text) || (( SELECT t_zl_pipelinepoints_temp.mapdot
           FROM t_zl_pipelinepoints_temp
          WHERE ((t_zl_pipelinepoints_temp.id)::text = (t.endpoint)::text)))::text) AS name
   FROM t_zl_pipelinesections_temp t;
