create function "_postgis_scripts_pgsql_version"() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '95'::text AS version
$$;
