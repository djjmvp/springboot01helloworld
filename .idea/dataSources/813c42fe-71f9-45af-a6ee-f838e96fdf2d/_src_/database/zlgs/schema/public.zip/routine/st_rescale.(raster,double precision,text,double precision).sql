create function st_rescale(rast raster, scalexy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT  public._ST_GdalWarp($1, $3, $4, NULL, $2, $2)
$$;
