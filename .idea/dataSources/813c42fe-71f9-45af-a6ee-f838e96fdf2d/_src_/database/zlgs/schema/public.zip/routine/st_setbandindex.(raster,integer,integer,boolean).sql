create function st_setbandindex(rast raster, band integer, outdbindex integer, force boolean DEFAULT false) returns raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_SetBandPath($1, $2, NULL, $3, $4)
$$;
