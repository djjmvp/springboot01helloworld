CREATE VIEW zl_xfs AS SELECT t_zl_pipelinepoints.type,
    t_zl_pipelinepoints.geom
   FROM t_zl_pipelinepoints
  WHERE (((t_zl_pipelinepoints.type)::text = 'xhs'::text) OR ((t_zl_pipelinepoints.type)::text = 'xfsh'::text));
