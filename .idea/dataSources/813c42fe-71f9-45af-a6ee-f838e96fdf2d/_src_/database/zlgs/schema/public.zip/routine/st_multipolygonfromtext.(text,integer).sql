create function st_multipolygonfromtext(text, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_MPolyFromText($1, $2)
$$;
