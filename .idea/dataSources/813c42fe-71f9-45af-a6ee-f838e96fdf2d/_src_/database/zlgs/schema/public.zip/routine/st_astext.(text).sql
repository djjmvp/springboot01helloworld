create function st_astext(text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_AsText($1::public.geometry);
$$;
