CREATE VIEW point2 AS SELECT (((a.t1)::text || '-'::text) || (
        CASE
            WHEN (a.t2 IS NULL) THEN ''::character varying
            ELSE a.t2
        END)::text) AS type,
    a.geom,
    a.id,
    a.mapdot,
    a.devicetype,
    a.status,
    a.switchstate,
    a.completiondate,
    a.bore,
    a.materials,
    a.types
   FROM ( SELECT t1.type AS t1,
            t2.type AS t2,
            t1.geom,
            t1.id,
            t1.mapdot,
            t1.completiondate,
            t3.codename AS bore,
            t4.codename AS materials,
            t5.codename AS types,
            t1.devicetype,
            t1.status,
            t2.switchstate
           FROM ((((t_zl_pipelinepoints t1
             LEFT JOIN t_zl_valve t2 ON (((t1.id)::text = (t2.id)::text)))
             LEFT JOIN t_zl_code t3 ON ((((t3.codecode)::text = (t1.bore)::text) AND ((t3.codetype)::text = '管点口径'::text))))
             LEFT JOIN t_zl_code t4 ON ((((t4.codecode)::text = (t1.materials)::text) AND ((t4.codetype)::text = '管点材质'::text))))
             LEFT JOIN t_zl_code t5 ON ((((t5.codecode)::text = (t1.type)::text) AND ((t5.codetype)::text = '管点类型'::text))))) a;
