create function postgis_scripts_build_date() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2018-12-02 02:54:25'::text AS version
$$;
