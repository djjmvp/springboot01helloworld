create function postgis_raster_scripts_installed() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.5.1'::text || ' r' || 17027::text AS version
$$;
