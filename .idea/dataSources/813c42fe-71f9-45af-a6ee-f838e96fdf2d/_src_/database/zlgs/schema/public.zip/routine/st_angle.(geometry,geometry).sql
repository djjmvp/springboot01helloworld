create function st_angle(line1 geometry, line2 geometry) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_Angle(St_StartPoint($1), ST_EndPoint($1), St_StartPoint($2), ST_EndPoint($2))
$$;
