create function st_length_spheroid(geometry, spheroid) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Length_Spheroid', 'ST_LengthSpheroid', '2.2.0');
    SELECT public.ST_LengthSpheroid($1,$2);
$$;
