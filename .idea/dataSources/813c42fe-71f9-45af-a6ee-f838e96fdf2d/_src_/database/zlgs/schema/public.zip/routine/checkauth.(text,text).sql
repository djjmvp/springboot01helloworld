create function checkauth(text, text) returns integer
LANGUAGE SQL
AS $$
SELECT CheckAuth('', $1, $2)
$$;
