create function st_distance(text, text) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);
$$;
