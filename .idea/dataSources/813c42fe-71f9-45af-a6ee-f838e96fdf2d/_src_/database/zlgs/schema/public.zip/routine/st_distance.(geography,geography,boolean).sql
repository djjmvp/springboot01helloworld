create function st_distance(geography, geography, boolean) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_Distance($1, $2, 0.0, $3)
$$;
