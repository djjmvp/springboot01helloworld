create function st_approxsummarystats(rast raster, sample_percent double precision) returns summarystats
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_summarystats($1, 1, TRUE, $2)
$$;
