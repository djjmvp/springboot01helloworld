CREATE VIEW zl_point_temp AS SELECT ((a.t1)::text || '-'::text) AS type,
    a.geom,
    a.id,
    a.mapdot,
    a.devicetype,
    a.status,
    a.switchstate,
    a.completiondate,
    a.bore,
    a.materials,
    a.types,
    a.x,
    a.y
   FROM ( SELECT t1.type AS t1,
            t2.type AS t2,
            t1.geom,
            t1.id,
            t1.mapdot,
            t1.completiondate,
            t3.codename AS bore,
            t1.materials,
            t1.type AS types,
            t1.status,
            t2.switchstate,
            t1.x,
            t4.devicetype,
            t1.y
           FROM (((t_zl_pipelinepoints_temp t1
             LEFT JOIN t_zl_valve t2 ON (((t1.id)::text = (t2.id)::text)))
             LEFT JOIN t_zl_code t3 ON ((((t3.codecode)::text = (t1.bore)::text) AND ((t3.codetype)::text = '管点口径'::text))))
             LEFT JOIN t_zl_watermeter t4 ON (((t4.id)::text = (t1.id)::text)))) a;
