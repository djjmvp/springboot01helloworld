CREATE VIEW zl_pipeline AS SELECT ( SELECT t_zl_pipelinepoints.mapdot
           FROM t_zl_pipelinepoints
          WHERE ((t_zl_pipelinepoints.id)::text = (t.startpoint)::text)) AS startpoint,
    ( SELECT t_zl_pipelinepoints.mapdot
           FROM t_zl_pipelinepoints
          WHERE ((t_zl_pipelinepoints.id)::text = (t.endpoint)::text)) AS endpoint,
    t.id,
    t.geom,
    t.mainorbranch,
    (((( SELECT t_zl_pipelinepoints.mapdot
           FROM t_zl_pipelinepoints
          WHERE ((t_zl_pipelinepoints.id)::text = (t.startpoint)::text)))::text || '~'::text) || (( SELECT t_zl_pipelinepoints.mapdot
           FROM t_zl_pipelinepoints
          WHERE ((t_zl_pipelinepoints.id)::text = (t.endpoint)::text)))::text) AS name,
    t.startpoint AS startpointid,
    t.endpoint AS endpointid,
    t.completiondate,
    t.type,
    t.material,
    t3.codename AS pipediameter,
    t4.x AS x1,
    t4.y AS y1,
    t5.x AS x2,
    t5.y AS y2
   FROM (((t_zl_pipelinesections t
     LEFT JOIN t_zl_code t3 ON ((((t3.codecode)::text = (t.pipediameter)::text) AND ((t3.codetype)::text = '管径'::text))))
     LEFT JOIN t_zl_pipelinepoints t4 ON (((t4.id)::text = (t.startpoint)::text)))
     LEFT JOIN t_zl_pipelinepoints t5 ON (((t5.id)::text = (t.endpoint)::text)));
