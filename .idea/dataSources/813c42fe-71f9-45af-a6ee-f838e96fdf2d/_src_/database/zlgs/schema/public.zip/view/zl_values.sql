CREATE VIEW zl_values AS SELECT b.switchstate,
    a.geom
   FROM t_zl_valve b,
    t_zl_pipelinepoints a
  WHERE ((a.id)::text = (b.id)::text);
COMMENT ON VIEW zl_values IS '阀门状态显示';
