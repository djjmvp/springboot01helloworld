CREATE VIEW zl_point_bak AS SELECT ((a.t1)::text || '-'::text) AS type,
    a.geom,
    a.baktime,
    a.id,
    a.mapdot,
    a.devicetype,
    a.status
   FROM ( SELECT t1.type AS t1,
            t2.type AS t2,
            t1.geom,
            t1.baktime,
            t1.id,
            t1.mapdot,
            t1.devicetype,
            t1.status
           FROM (t_zl_pipelinepoints_bak t1
             LEFT JOIN t_zl_valve t2 ON (((t1.id)::text = (t2.id)::text)))) a;
